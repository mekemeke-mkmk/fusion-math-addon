"""Compatibility entry point for the add-in."""

from math_curve_2.math_curve_2 import main


if __name__ == "__main__":
    main()
