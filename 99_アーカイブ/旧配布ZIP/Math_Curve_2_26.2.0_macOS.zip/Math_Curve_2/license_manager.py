"""Autodesk Design and Make Marketplace entitlement checks for Math Curve."""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


# This is the Marketplace ID assigned to the Math Curve 2 preview submission.
MARKETPLACE_APP_ID = "1343581627431012464"
ENTITLEMENT_ENDPOINT = "https://apps.autodesk.com/webservices/checkentitlement"
OFFLINE_GRACE_PERIOD = timedelta(days=7)
LICENSE_CACHE_FILE = "math_curve_2_entitlement.json"


@dataclass(frozen=True)
class LicenseStatus:
    allowed: bool
    mode: str
    message: str


def _cache_path() -> str:
    if sys.platform == "darwin":
        app_data = os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    else:
        app_data = os.getenv("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(app_data, "Autodesk", "MathCurve")
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, LICENSE_CACHE_FILE)


def _read_cache() -> dict[str, Any]:
    try:
        with open(_cache_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return {}


def _write_cache(data: dict[str, Any]) -> None:
    path = _cache_path()
    temporary_path = f"{path}.tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
    os.replace(temporary_path, path)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _get_fusion_user_id(app: Any) -> str:
    """Return Fusion's Autodesk account ID, which the Marketplace API expects."""
    try:
        return str(app.userId or "").strip()
    except Exception:
        return ""


def _parse_entitlement(payload: Any, user_id: str) -> LicenseStatus:
    if not isinstance(payload, dict):
        return LicenseStatus(False, "verification_error", "The Marketplace returned an invalid license response.")

    if payload.get("UserId") not in (None, "", user_id):
        return LicenseStatus(False, "verification_error", "The Marketplace license response was for a different user.")
    if str(payload.get("AppId", MARKETPLACE_APP_ID)) != MARKETPLACE_APP_ID:
        return LicenseStatus(False, "verification_error", "The Marketplace license response was for a different app.")

    if payload.get("IsValid") is True:
        return LicenseStatus(True, "entitled", "Marketplace entitlement verified.")

    marketplace_message = str(payload.get("Message") or "No active Marketplace entitlement was found.")
    return LicenseStatus(
        False,
        "not_entitled",
        "Your 30-day trial has ended or this Autodesk account does not have an active license. "
        f"Marketplace response: {marketplace_message}",
    )


def _request_entitlement(user_id: str) -> LicenseStatus:
    query = urlencode({"userid": user_id, "appid": MARKETPLACE_APP_ID})
    request = Request(
        f"{ENTITLEMENT_ENDPOINT}?{query}",
        headers={"Accept": "application/json", "User-Agent": "MathCurve/26.2.0"},
    )
    try:
        with urlopen(request, timeout=10) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, OSError, TimeoutError, UnicodeDecodeError, json.JSONDecodeError):
        return LicenseStatus(False, "connection_error", "Unable to contact Autodesk Marketplace to verify your license.")

    return _parse_entitlement(payload, user_id)


def _store_verified_entitlement(user_id: str) -> None:
    _write_cache(
        {
            "app_id": MARKETPLACE_APP_ID,
            "user_id": user_id,
            "verified_at": _utc_now().isoformat(),
        }
    )


def _offline_grace_status(user_id: str) -> LicenseStatus | None:
    cache = _read_cache()
    if cache.get("app_id") != MARKETPLACE_APP_ID or cache.get("user_id") != user_id:
        return None
    try:
        verified_at = datetime.fromisoformat(str(cache["verified_at"]))
        if verified_at.tzinfo is None:
            return None
    except (KeyError, TypeError, ValueError):
        return None

    if _utc_now() - verified_at <= OFFLINE_GRACE_PERIOD:
        return LicenseStatus(
            True,
            "offline_grace",
            "Marketplace entitlement was previously verified; offline grace period is active.",
        )
    return None


def check_license(app: Any) -> LicenseStatus:
    """Verify this signed-in Fusion user with Autodesk's Marketplace service.

    Marketplace owns the 30-day trial and paid entitlement state. This add-in
    never starts or extends trials locally.
    """
    user_id = _get_fusion_user_id(app)
    if not user_id:
        return LicenseStatus(
            False,
            "signed_out",
            "Sign in to Fusion with your Autodesk account to verify the Math Curve license.",
        )

    status = _request_entitlement(user_id)
    if status.mode == "connection_error":
        return _offline_grace_status(user_id) or status
    if status.allowed:
        _store_verified_entitlement(user_id)
    return status
